const signUp = document.getElementById("signup-btn");
const signUpModal = document.getElementById("signup-modal");
const signUpModalClose = document.getElementById("signup-modal-close");
const wrapper = document.getElementById("wrapper");
const signUpSubmit = document.getElementById("sign-up-submit");
const notification = document.getElementById("notification");
const dashBoard = document.getElementById("dashboard");
const logoutBtn = document.getElementById("logout-btn");


const loginBtn = document.getElementById("login-btn");
const loginModal = document.getElementById("login-modal");
const loginModalClose = document.getElementById("login-modal-close");
const loginSubmit = document.getElementById("login-submit");
const authSection = document.getElementById("auth-section");


const allBooks = document.getElementById("all-books");
const logo = document.getElementById("logo");

//  CHECK IF USER IS LOGGED IN
(function isLoggedIn() {
    if(Boolean(localStorage.getItem("USER_LOGGED_IN"))){
        const userMail = localStorage.getItem("USER_LOGGED_IN");
        loginBtn.insertAdjacentHTML("beforebegin",`<li style="color: black" id="user-mail">${userMail}</li>`);
        loginBtn.style.display = "none";
        signUp.style.display = "none";

        dashBoard.style.display = "block";
        logoutBtn.style.display = "block";
    }
})();

// LOGOUT USER
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem("USER_LOGGED_IN");
    logoutBtn.style.display = "none";
    dashBoard.style.display = "none";
    loginBtn.style.display = "block";
    signUp.style.display = "block";

    authSection.removeChild(authSection.children[0]);

    const locationArray = location.href.split("/");
    if(locationArray[locationArray.length - 1] === "dashboard.html") {
        location.href = "index.html"
    }
})

// CLICK ON LOGO
logo.addEventListener("click", () => {
    location.href = "index.html";
});

// CLICK ON ALL BOOKS
allBooks.addEventListener("click", () => {
    location.href = "books.html";
});

// CLICK ON DASHBOARD
dashBoard.addEventListener("click", () => {
    location.href = "dashboard.html";
});

signUp.addEventListener('click', () => {
    signUpModal.style.display = "block";
    wrapper.style.filter = "blur(2px)";
});

loginBtn.addEventListener('click', () => {
    loginModal.style.display = "block";
    wrapper.style.filter = "blur(2px)";
});

signUpModalClose.addEventListener('click', () => {
    document.getElementById("signup-form").reset();
    signUpModal.style.display = "none";
    wrapper.style.filter = "blur(0px)";
});

loginModalClose.addEventListener('click', () => {
    document.getElementById("login-form").reset();
    loginModal.style.display = "none";
    wrapper.style.filter = "blur(0px)";
});

signUpSubmit.addEventListener('click', (e) => {
    e.preventDefault();
    const newUser = {
        name: document.getElementById("name").value,
        surname: document.getElementById("surname").value,
        mail: document.getElementById("mail").value,
        password: document.getElementById("password").value,
    };

    axios.post("http://localhost:3000/api/books/signup", newUser)
        .then((response) => {
            notification.textContent = "SUCCESS";
            notification.classList.add("success", "animation");
            document.getElementById("signup-form").reset();
            signUpModal.style.display = "none";
            wrapper.style.filter = "blur(0px)";
            setTimeout(() => notification.classList = "notification", 3000)
        })
        .catch((err) => {
            console.log('error', err);
            notification.textContent = "ERROR";
            notification.classList.add("error", "animation");
            setTimeout(() => notification.classList = "notification", 3000);
        })
});


loginSubmit.addEventListener('click', (e) => {
    e.preventDefault();
    const loginData = {
        mail: document.getElementById("login-mail").value,
        password: document.getElementById("login-password").value
    };

    function logUserIn(userMail) {
        localStorage.setItem("USER_LOGGED_IN", `${userMail}`);
        loginBtn.insertAdjacentHTML("beforebegin",`<li style="color: black">${userMail}</li>`);
        loginBtn.style.display = "none";
        logoutBtn.style.display = "block";
        signUp.style.display = "none";
        dashBoard.style.display = "block";
    };

    axios.post("http://localhost:3000/api/books/login", loginData)
        .then(() => {
            notification.textContent = "SUCCESS";
            document.getElementById("login-form").reset();
            loginModal.style.display = "none";
            wrapper.style.filter = "blur(0px)";
            notification.classList.add("success", "animation");
            setTimeout(() => notification.classList = "notification", 3000);
            logUserIn(loginData.mail);
        })
        .catch((err) => {
            console.log(err);
            notification.textContent = "ERROR OCCURED";
            notification.classList.add("error", "animation");
            setTimeout(() => notification.classList = "notification", 3000);
        })
})