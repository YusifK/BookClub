const dashboardTableWrapper = document.getElementById("dash-table");
const bookDetailsModal = document.getElementById("book-details-modal");
const bookDetailsModalClose = document.getElementById("book-details-modal-close");
const bookDetailsModalSubmitBtn = document.getElementById("book-details-submit");
const bookDetailsModalForm = document.getElementById("book-details-modal-form");

bookDetailsModalSubmitBtn.addEventListener('click', (e) => {
    e.preventDefault();

    const newBook =  {
        id: document.getElementById("id").value,
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        publisher : document.getElementById("publisher").value,
        publishDay : document.getElementById("publishDay").value,
        sold: document.getElementById("sold").value,
        genre: [],
        imageUrl: document.getElementById("imageUrl").value,
        synopsis: document.getElementById("synopsis").value,
        bookCover: Boolean(document.getElementById("hard").checked) ? "hard" : "soft",
        price: document.getElementById("price").value,
    }

    const allCheckBoxes = document.querySelectorAll('input[type="checkbox"]:checked');
    for(let i=0; i < allCheckBoxes.length; i++) {
        newBook.genre.push(allCheckBoxes[i].value)
    }

    axios.post("http://localhost:3000/api/books", newBook)
        .then(() => {
            notification.textContent = "SUCCESS";
            notification.classList.add("success", "animation");
            setTimeout(() => notification.classList = "notification", 3000);
            handleBookDetailsModalClose();
            fetchAllBooks();
        });
})


function createAddBookAction() {
    const addBookBtn = document.getElementById("book-details-modal-add");
    addBookBtn.addEventListener("click", handleDetailsModalOpen);
}


function handleDetailsModalOpen() {
    bookDetailsModal.style.display = "block";
    wrapper.style.filter = "blur(3px) opacity(20%)";
}

function handleBookDetailsModalClose() {
    bookDetailsModal.style.display = "none";
    wrapper.style.filter = "none";
    bookDetailsModalForm.reset();
}

bookDetailsModalClose.addEventListener('click', handleBookDetailsModalClose);


function deleteEditBookById() {
    const tableDataWrapper = dashboardTableWrapper.firstElementChild;
    for(let i=1; i < tableDataWrapper.children.length; i++) {
        const deleteIcon = tableDataWrapper.children[i].children[0].lastElementChild.firstElementChild;
        const editIcon = tableDataWrapper.children[i].children[0].lastElementChild.lastElementChild;

        deleteIcon.addEventListener('click', () => {
            const id = deleteIcon.id.split("-")[2];
            
            axios.delete(`http://localhost:3000/api/books/${id}`)
                .then(() => {
                    notification.textContent = "SUCCESS";
                    notification.classList.add("success", "animation");
                    setTimeout(() => notification.classList = "notification", 3000);

                    fetchAllBooks();
                })
        });

        editIcon.addEventListener('click', () => {
            const id = editIcon.id.split("-")[2];
            axios.get(`http://localhost:3000/api/books/${id}`)
                .then(({data: bookById}) => {
                    handleDetailsModalOpen();


                    document.getElementById("id").value = bookById.id;
                    document.getElementById("title").value = bookById.title;
                    document.getElementById("author").value = bookById.author;
                    document.getElementById("publisher").value = bookById.publisher;
                    document.getElementById("publishDay").value = bookById.publishDay;
                    document.getElementById("sold").value = bookById.sold;
                    document.getElementById("imageUrl").value = bookById.imageUrl;
                    document.getElementById("synopsis").value = bookById.synopsis;
                    document.getElementById("price").value = bookById.price;

                    bookById.bookCover == "hard" ? document.getElementById("hard").checked == true : document.getElementById("soft").checked;

                    bookById.genre.map(genreItem => {
                        const allGenres = document.querySelectorAll('input[type="checkbox"]');
                        for(let i=0; i < allGenres.length; i++) {
                            if(allGenres[i].value === genreItem) {
                                allGenres[i].checked = true;
                                break;
                            }
                        }
                    })
                })

        })
    }
}

function renderAllBooks(bookList) {
    dashboardTableWrapper.innerHTML = "";
    const bookTable = `
        <table>
            <tr>
                <th>#id</th>
                <th>Title</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>Price</th>
                <th>
                    <img src="./assets/icons/cancel.svg" alt="add" class="book-details-modal__add" id="book-details-modal-add">
                </th>
            </tr>
        </table>
    `;
    dashboardTableWrapper.insertAdjacentHTML("afterbegin", bookTable);
    bookList.map(book => {
        dashboardTableWrapper.firstElementChild.insertAdjacentHTML("beforeend", `
            <tr>
                <td>${book.id}</td>
                <td>${book.title}</td>
                <td>${book.author}</td>
                <td>${book.publisher}</td>
                <td>$${book.price}</td>
                <td>
                    <img src='./assets/icons/delete.svg' id="delete-book-${book.id}">
                    <img src='./assets/icons/pencil.svg' id="edit-book-${book.id}">
                </td>
            </tr>
        `);
    })
    createAddBookAction();
    deleteEditBookById();
} 

function fetchAllBooks() {
    axios.get("http://localhost:3000/api/books")
    .then(response => {
        renderAllBooks(response.data);
    })
    .catch(err => console.log(err));         
};

(function getActiveNavItem() {
    const booksTab = document.getElementById("books-dash");
    const authorsTab = document.getElementById("authors-dash");
    const usersTab = document.getElementById("users-dash");

    booksTab.addEventListener('click', () => {
        authorsTab.className = "";
        usersTab.className = "";
        booksTab.className = "dashboard__navigation__active";
        fetchAllBooks();
    });

    authorsTab.addEventListener('click', () => {
        booksTab.className = "";
        usersTab.className = "";
        authorsTab.className = "dashboard__navigation__active";
    });

    usersTab.addEventListener('click', () => {
        booksTab.className = "";
        authorsTab.className = "";
        usersTab.className = "dashboard__navigation__active";
    });
})();
